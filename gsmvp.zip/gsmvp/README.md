

  1.Xutils    3.5.0   github地址:https://github.com/wyouflf/xUtils3 
  
  2.Gson      2.8.0   github地址:https://github.com/google/gson
  
  3.EnentBus  3.0.0   github地址:https://github.com/greenrobot/EventBus
  
  4.BadgeView 1.1.0   github地址:https://github.com/qstumn/BadgeView
  
  5.Banner    1.4.9   github地址:https://github.com/youth5201314/banner
