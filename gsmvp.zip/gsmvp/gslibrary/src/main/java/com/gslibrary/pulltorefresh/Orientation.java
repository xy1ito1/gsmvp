package com.gslibrary.pulltorefresh;

public enum Orientation {
    VERTICAL, HORIZONTAL;
	}
