package com.mvpgs.utils;

/*********************************************
 ***       河南坚磐科技电子有限公司        ***
 ***                                       ***
 ***       Created by HC on 2017/4/24.       ***
 *********************************************/

public class UrlConston {

    public static String url="http://v.juhe.cn/weather/index";

    public static String aus="http://tadmin.midian001.com/australia/appOrderController/getOrderList";
}
